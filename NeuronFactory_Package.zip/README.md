# Neuron Factory — Download & Run (Desktop)

This package is designed to feel like a normal local app:
- You click an icon/launcher
- A local server starts in the background
- Your browser opens to the UI

## Supported devices
✅ Windows / macOS / Linux (desktop/laptop)
⚠️ iOS/Android cannot run this as a normal desktop app without special environments (Termux/Pydroid). For phones/tablets, the simplest path is hosting the server.

## One-click launch (first run installs deps)
### Windows
Double-click: `run_windows.bat`

### macOS
Right-click `run_mac.command` → Open (first time Gatekeeper prompt)  
OR in Terminal:
```bash
chmod +x run_mac.command run_linux.sh
./run_mac.command
```

### Linux
```bash
chmod +x run_linux.sh
./run_linux.sh
```

This will:
1) Create a `.venv` virtual environment
2) Install dependencies
3) Start the app on http://127.0.0.1:8000
4) Open your browser automatically (if supported)

## Create a desktop icon
### Windows (PowerShell)
Right-click `create_desktop_shortcut_windows.ps1` → Run with PowerShell

### Linux
Copy `NeuronFactory.desktop` to `~/.local/share/applications/` and edit the path inside.

### macOS
For a true clickable `.app` with an icon, use the `build_native/` scripts.

## Native builds (no Python needed for end-users)
Build per-OS using PyInstaller (cannot cross-compile reliably):
See `build_native/README.md`
