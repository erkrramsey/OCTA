# Native Builds (Real App Icon, No Python Needed)

You cannot ship one single binary that runs on every OS/device.
Build per platform:

- Windows: build on Windows
- macOS: build on macOS
- Linux: build on Linux

## Install build deps
```bash
python -m pip install --upgrade pip
pip install pyinstaller
pip install -r ../requirements.txt
```

## Build
### Windows (PowerShell)
```powershell
cd build_native
pyinstaller --noconsole --onefile --name NeuronFactory ..\app\Neuron_Factory_v7_OCTA_UI.py
```

### macOS / Linux
```bash
cd build_native
pyinstaller --noconsole --onefile --name NeuronFactory ../app/Neuron_Factory_v7_OCTA_UI.py
```

Output: `build_native/dist/`

## Notes
- For a true macOS `.app` bundle + custom icon, we can add a PyInstaller `.spec`.
- If you want the UI to auto-open reliably, we can embed that directly in the Python app.
