# QC Geometric Energy Cell — Report v0.28.0
- created_ms: 1770429979698
- scipy_available: True

## Jobs
### AB_n4_4
- kind: AB
- points: 1281  edges: 2056  deg_mean: 3.21
- components: 59  largest_frac: 0.862  top5: [1104, 64, 8, 8, 8]
- electrode_connected_frac: 0.868
- selected_edges: 164  deploy_frac: 0.080
- motif_selected_mean: 1.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1587.3  N_dump_in_T≈20793.7  selected/N_dump≈0.0079
- resistor: G_eff≈0.503729 (method=spsolve)

### AB_n4_5
- kind: AB
- points: 1673  edges: 3184  deg_mean: 3.81
- components: 18  largest_frac: 0.990  top5: [1656, 1, 1, 1, 1]
- electrode_connected_frac: 0.992
- selected_edges: 255  deploy_frac: 0.080
- motif_selected_mean: 1.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1587.3  N_dump_in_T≈20793.7  selected/N_dump≈0.0123
- resistor: G_eff≈0.820981 (method=spsolve)

### PEN_wave_small
- kind: PENW
- points: 948  edges: 2762  deg_mean: 5.83
- components: 26  largest_frac: 0.077  top5: [73, 72, 65, 65, 64]
- electrode_connected_frac: 0.148
- selected_edges: 221  deploy_frac: 0.080
- motif_selected_mean: 1.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1587.3  N_dump_in_T≈20793.7  selected/N_dump≈0.0106
- resistor: G_eff≈-0.000000 (method=spsolve)

### PEN_wave_med
- kind: PENW
- points: 1309  edges: 3823  deg_mean: 5.84
- components: 31  largest_frac: 0.063  top5: [83, 80, 75, 73, 70]
- electrode_connected_frac: 0.162
- selected_edges: 306  deploy_frac: 0.080
- motif_selected_mean: 1.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1587.3  N_dump_in_T≈20793.7  selected/N_dump≈0.0147
- resistor: G_eff≈-0.000000 (method=spsolve)

### PEN_wave_large
- kind: PENW
- points: 2100  edges: 7122  deg_mean: 6.78
- components: 28  largest_frac: 0.072  top5: [151, 149, 135, 133, 130]
- electrode_connected_frac: 0.156
- selected_edges: 570  deploy_frac: 0.080
- motif_selected_mean: 1.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1587.3  N_dump_in_T≈20793.7  selected/N_dump≈0.0274
- resistor: G_eff≈-0.000000 (method=spsolve)

### PEN_cp_variant
- kind: PENCP
- points: 1801  edges: 5997  deg_mean: 6.66
- components: 1  largest_frac: 1.000  top5: [1801]
- electrode_connected_frac: 1.000
- selected_edges: 480  deploy_frac: 0.080
- motif_selected_mean: 0.911
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1741.6  N_dump_in_T≈22815.3  selected/N_dump≈0.0210
- resistor: G_eff≈2.068930 (method=spsolve)

### SQUARE_ctrl
- kind: SQUARE
- points: 1369  edges: 2664  deg_mean: 3.89
- components: 1  largest_frac: 1.000  top5: [1369]
- electrode_connected_frac: 1.000
- selected_edges: 160  deploy_frac: 0.060
- motif_selected_mean: 0.000
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈13951528.1  N_dump_in_T≈182765017.8  selected/N_dump≈0.0000
- resistor: G_eff≈1.224918 (method=spsolve)

### HYBRID_AB4_PENmed
- kind: HYBRID
- points: 1281  edges: 2056  deg_mean: 3.21
- components: 59  largest_frac: 0.862  top5: [1104, 64, 8, 8, 8]
- electrode_connected_frac: 0.868
- selected_edges: 206  deploy_frac: 0.100
- motif_selected_mean: 0.990
- energy(sim): dumps=0  dump_rate_hz=0.0000  avg_power_uW=0.0000
- energy(feas): N_break_even≈1602.9  N_dump_in_T≈20997.5  selected/N_dump≈0.0098
- resistor: G_eff≈0.502737 (method=spsolve)

