from __future__ import annotations
import argparse, os, json, time
from typing import Dict, Any, List
import requests

from .codec import (
    decompress, decode_patch_list, Patch,
    H, empty_patch_list_raw, encode_patch_list,
    bytes_to_hex
)
from .state_lmdb import LMDBState
from .merkle import merkle_root, merkle_verify_leaf

def shard_leaf(shard_id: int, raw: bytes) -> bytes:
    return H(b"shard|" + shard_id.to_bytes(2, "big") + H(raw))

def fetch_manifest(relay: str, chain_id: str, block_no: int, cache_root: str) -> Dict[str, Any]:
    from .http_cache import load_etag, save_etag, get_with_etag
    key = f"manifest_{chain_id}_{block_no}"
    et = load_etag(cache_root, key)
    status, j, blob, new_et = get_with_etag(f"{relay}/v1/chain/{chain_id}/block/{block_no}/manifest", et, timeout=60)
    if new_et:
        save_etag(cache_root, key, new_et)
    if status == 304:
        # manifest is immutable for given blockNo in our store; but client still needs it.
        # If 304, we cannot reconstruct without persisted manifest. For simplicity, we re-fetch without etag.
        status, j, blob, new_et = get_with_etag(f"{relay}/v1/chain/{chain_id}/block/{block_no}/manifest", None, timeout=60)
        if new_et:
            save_etag(cache_root, key, new_et)
        return j
    return j

def fetch_shard(relay: str, chain_id: str, block_no: int, shard_id: int, cache_root: str) -> tuple[bytes, bool]:
    """
    Returns (blob, from_cache_skip)
    - If server returns 304, we skip download and return (b"", True) meaning "unchanged".
    """
    from .http_cache import load_etag, save_etag, get_with_etag
    key = f"shard_{chain_id}_{block_no}_{shard_id}"
    et = load_etag(cache_root, key)
    try:
        status, j, blob, new_et = get_with_etag(f"{relay}/v1/chain/{chain_id}/block/{block_no}/shard/{shard_id}", et, timeout=120)
        if new_et:
            save_etag(cache_root, key, new_et)
        if status == 304:
            return (b"", True)
        return (blob, False)
    except Exception as e:
        # shard may be empty (sparse)
        return (b"", False)

def cache_dir(root: str) -> str:
    d = os.path.join(root, "sidecar_cache")
    os.makedirs(d, exist_ok=True)
    return d

def cache_block_path(root: str, chain_id: str, block_no: int) -> str:
    d = os.path.join(cache_dir(root), f"chain_{chain_id}", f"block_{block_no:012d}")
    os.makedirs(d, exist_ok=True)
    return d

def cache_write_block(root: str, chain_id: str, block_no: int, manifest: dict, shard_raws: Dict[int, bytes]) -> None:
    d = cache_block_path(root, chain_id, block_no)
    with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
    for sid, raw in shard_raws.items():
        with open(os.path.join(d, f"shard_{sid:03d}.raw"), "wb") as f:
            f.write(raw)

def cache_read_block(root: str, chain_id: str, block_no: int) -> tuple[dict, Dict[int, bytes]]:
    d = cache_block_path(root, chain_id, block_no)
    with open(os.path.join(d, "manifest.json"), "r", encoding="utf-8") as f:
        man = json.load(f)
    raws: Dict[int, bytes] = {}
    for fn in os.listdir(d):
        if fn.startswith("shard_") and fn.endswith(".raw"):
            sid = int(fn.split("_")[1].split(".")[0])
            with open(os.path.join(d, fn), "rb") as f:
                raws[sid] = f.read()
    return man, raws


def prune_cache_keep_last(root: str, chain_id: str, keep: int) -> int:
    d = os.path.join(cache_dir(root), f"chain_{chain_id}")
    if keep <= 0 or not os.path.isdir(d):
        return 0
    blocks = cache_list_blocks(root, chain_id)
    if len(blocks) <= keep:
        return 0
    doomed = blocks[:-keep]
    removed = 0
    for b in doomed:
        bd = os.path.join(d, f"block_{b:012d}")
        try:
            import shutil
            shutil.rmtree(bd)
            removed += 1
        except Exception:
            pass
    return removed

def cache_list_blocks(root: str, chain_id: str) -> List[int]:
    d = os.path.join(cache_dir(root), f"chain_{chain_id}")
    if not os.path.isdir(d):
        return []
    out = []
    for name in os.listdir(d):
        if name.startswith("block_"):
            out.append(int(name.split("_")[1]))
    return sorted(out)

def rollback(state: LMDBState, root: str, chain_id: str, n: int) -> None:
    blocks = cache_list_blocks(root, chain_id)
    if not blocks:
        print("[Fast Replay] rollback: nothing cached")
        return
    targets = blocks[-min(n, len(blocks)):]
    print(f"[Fast Replay] rollback {len(targets)} blocks: {targets[0]}..{targets[-1]}")
    t0 = time.perf_counter()
    for b in reversed(targets):
        man, shard_raws = cache_read_block(root, chain_id, b)
        inv: List[Patch] = []
        for raw in shard_raws.values():
            plist = decode_patch_list(raw)
            inv.extend([p.invert() for p in plist])
        inv.sort(key=lambda p: p.sort_key())
        state.apply(inv)
    t1 = time.perf_counter()
    print(f"[Fast Replay] rollback done in {(t1-t0):.3f}s; stateCommit={state.commitment()[:18]}...")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--relay", default=os.environ.get("SIDECAR_RELAY_URL","http://127.0.0.1:8080"))
    ap.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    ap.add_argument("--state-dir", default=os.environ.get("SIDECAR_STATE_DIR","./state_lmdb"))
    ap.add_argument("--from-block", type=int, default=None)
    ap.add_argument("--count", type=int, default=1)
    ap.add_argument("--verify-mac", action="store_true")
    ap.add_argument("--verify-proof-shard", type=int, default=-1, help="Verify Merkle proof for shardId (0..255)")
    ap.add_argument("--map-size-gb", type=int, default=8)
    ap.add_argument("--rollback", type=int, default=0, help="Rollback last N cached blocks")
    args = ap.parse_args()

    st = LMDBState(args.state_dir, map_size_bytes=int(args.map_size_gb)*1024**3)

    if args.rollback > 0:
        rollback(st, args.state_dir, args.chain_id, args.rollback)
        return

    if args.from_block is None:
        raise SystemExit("--from-block required unless --rollback is used")

    empty_raw = empty_patch_list_raw()
    empty_leaf = [shard_leaf(i, empty_raw) for i in range(256)]

    for b in range(args.from_block, args.from_block + args.count):
        man = fetch_manifest(args.relay, args.chain_id, b, args.state_dir)
        comp = man["compressor"]
        mac = bytes.fromhex(man["macV1MerkleRoot"][2:])
        sparse = man.get("shards", {}) or {}

        # Fetch only non-empty shards; keep raw for rollback cache
        shard_raws: Dict[int, bytes] = {}
        leaves = empty_leaf[:]  # dense

        patches: List[Patch] = []
        for sid_str, meta in sparse.items():
            sid = int(sid_str)
            blob, skipped = fetch_shard(args.relay, args.chain_id, b, sid, args.state_dir)

            if skipped:
                # Try rollback cache raw shard; if not available, force re-fetch
                try:
                    d = cache_block_path(args.state_dir, args.chain_id, b)
                    rp = os.path.join(d, f"shard_{sid:03d}.raw")
                    if os.path.exists(rp):
                        with open(rp, "rb") as f:
                            raw = f.read()
                        leaf = shard_leaf(sid, raw)
                        if ("hash" in meta) and (meta["hash"][2:] != leaf.hex()):
                            raise RuntimeError(f"cached raw shard hash mismatch b={b} sid={sid}")
                        leaves[sid] = leaf
                        shard_raws[sid] = raw
                        patches.extend(decode_patch_list(raw))
                        continue
                except Exception:
                    pass
                # Fallthrough: force re-fetch without etag
                from .http_cache import save_etag
                save_etag(args.state_dir, f"shard_{args.chain_id}_{b}_{sid}", None)
                blob, skipped = fetch_shard(args.relay, args.chain_id, b, sid, args.state_dir)

            if not blob:
                # should not happen (manifest says non-empty), but tolerate
                continue
            raw = decompress(comp, blob)
            leaf = shard_leaf(sid, raw)
            if ("hash" in meta) and (meta["hash"][2:] != leaf.hex()):
                raise RuntimeError(f"shard hash mismatch b={b} sid={sid}")
            leaves[sid] = leaf
            shard_raws[sid] = raw
            patches.extend(decode_patch_list(raw))

        # Verify MAC root
        if args.verify_mac:
            got = merkle_root(leaves)
            if got != mac:
                raise RuntimeError(f"MAC mismatch b={b}: got {bytes_to_hex(got)} want {man['macV1MerkleRoot']}")

        # Optional: verify proof for one shard
        if 0 <= args.verify_proof_shard <= 255:
            sid = int(args.verify_proof_shard)
            pr = requests.get(f"{args.relay}/v1/chain/{args.chain_id}/block/{b}/proof/{sid}", timeout=60)
            pr.raise_for_status()
            pj = pr.json()
            proof = [bytes.fromhex(x[2:]) for x in pj["proof"]]
            leaf = bytes.fromhex(pj["leaf"][2:])
            root = bytes.fromhex(pj["macV1MerkleRoot"][2:])
            if not merkle_verify_leaf(leaf, sid, proof, root):
                raise RuntimeError(f"proof verify failed b={b} sid={sid}")

        # Apply
        patches.sort(key=lambda p: p.sort_key())
        st.apply(patches)

        # Cache for rollback
        cache_write_block(args.state_dir, args.chain_id, b, man, shard_raws)
        keep = int(os.environ.get('SIDECAR_CACHE_KEEP', '2048'))
        pruned = prune_cache_keep_last(args.state_dir, args.chain_id, keep)
        if pruned:
            print(f"[Fast Replay] cache pruned={pruned} keep={keep}")

        print(f"[Fast Replay] applied block={b} patches={len(patches)} nonEmptyShards={len(sparse)} mac={man['macV1MerkleRoot'][:18]}... stateCommit={st.commitment()[:18]}...")

    print("[Fast Replay] DONE")

if __name__ == "__main__":
    main()
