from __future__ import annotations
import os, json
from typing import Optional, Dict, Any, Tuple
import requests

def _cache_dir(root: str) -> str:
    d = os.path.join(root, "http_cache")
    os.makedirs(d, exist_ok=True)
    return d

def _key_path(root: str, key: str) -> str:
    safe = key.replace("/", "_").replace(":", "_")
    return os.path.join(_cache_dir(root), safe + ".json")

def load_etag(root: str, key: str) -> Optional[str]:
    p = _key_path(root, key)
    if not os.path.exists(p):
        return None
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f).get("etag")
    except Exception:
        return None

def save_etag(root: str, key: str, etag: Optional[str]) -> None:
    p = _key_path(root, key)
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump({"etag": etag}, f)
    except Exception:
        pass

def get_with_etag(url: str, etag: Optional[str], timeout: float = 60.0) -> Tuple[int, Dict[str, Any], bytes, Optional[str]]:
    headers = {}
    if etag:
        headers["If-None-Match"] = etag
    r = requests.get(url, headers=headers, timeout=timeout)
    new_etag = r.headers.get("ETag")
    if r.status_code == 304:
        return (304, {}, b"", new_etag or etag)
    r.raise_for_status()
    # try json
    ct = (r.headers.get("Content-Type") or "").lower()
    if "application/json" in ct or url.endswith("/manifest") or url.endswith("/mac") or url.endswith("/receipt") or url.endswith("/info"):
        try:
            return (r.status_code, r.json(), b"", new_etag)
        except Exception:
            return (r.status_code, {}, r.content, new_etag)
    return (r.status_code, {}, r.content, new_etag)
