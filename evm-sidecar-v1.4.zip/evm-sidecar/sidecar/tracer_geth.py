from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
from .rpc_pool import RpcPool
from .codec import Patch, TAG_BALANCE, TAG_NONCE, TAG_STORAGE, norm_addr, norm_slot, norm_word

def _extract_tx_diff_obj(item: Any) -> Tuple[Optional[str], Optional[Dict[str, Any]], Optional[str]]:
    if isinstance(item, dict):
        if "error" in item:
            return (item.get("txHash"), None, str(item.get("error")))
        if "result" in item:
            return (item.get("txHash"), item.get("result"), None)
        if "pre" in item or "post" in item:
            return (None, item, None)
    return (None, None, "unknown trace item")

def _build_patches_from_prepost(tx_index: int, diff: Dict[str, Any], include_storage: bool) -> List[Patch]:
    pre = diff.get("pre", {}) or {}
    post = diff.get("post", {}) or {}
    addrs = set(pre.keys()) | set(post.keys())
    out: List[Patch] = []

    for a in addrs:
        addr = norm_addr(a)
        pre_a = pre.get(a, {}) or {}
        post_a = post.get(a, {}) or {}

        if "balance" in post_a:
            out.append(Patch(tx_index, addr, TAG_BALANCE, None,
                             norm_word(pre_a.get("balance","0x0")),
                             norm_word(post_a["balance"])))

        if "nonce" in post_a:
            pre_nonce = int(pre_a.get("nonce", 0))
            post_nonce = int(post_a.get("nonce", 0))
            out.append(Patch(tx_index, addr, TAG_NONCE, None,
                             norm_word(hex(pre_nonce)),
                             norm_word(hex(post_nonce))))

        if include_storage:
            pre_s  = (pre_a.get("storage", {}) or {})
            post_s = (post_a.get("storage", {}) or {})

            for slot_k, slot_v in post_s.items():
                slot = norm_slot(slot_k)
                pre_v = norm_word(pre_s[slot_k]) if slot_k in pre_s else norm_word("0x0")
                out.append(Patch(tx_index, addr, TAG_STORAGE, slot, pre_v, norm_word(slot_v)))

            for slot_k, slot_v in pre_s.items():
                if slot_k not in post_s:
                    slot = norm_slot(slot_k)
                    out.append(Patch(tx_index, addr, TAG_STORAGE, slot, norm_word(slot_v), None))

    return out

def trace_block_state_deltas(pool: RpcPool, block_no: int, include_storage: bool = True) -> Tuple[List[Patch], Dict[str, str], str, int]:
    """
    Returns:
      patches, block_meta {hash,parentHash}, trace_mode ("block"|"per-tx"), trace_errors
    """
    block_tag = hex(block_no)
    blk = pool.call("eth_getBlockByNumber", [block_tag, False])
    if blk is None:
        raise RuntimeError(f"block not found {block_tag}")
    block_hash = blk.get("hash")
    parent_hash = blk.get("parentHash")
    txs = blk.get("transactions", []) or []

    tracer_cfg: Dict[str, Any] = {"diffMode": True, "disableCode": True}
    if not include_storage:
        tracer_cfg["disableStorage"] = True

    # Prefer per-block trace
    try:
        res = pool.call("debug_traceBlockByNumber", [block_tag, {"tracer":"prestateTracer","tracerConfig":tracer_cfg}])
        patches: List[Patch] = []
        errs = 0
        for i, item in enumerate(res):
            _, diff, err = _extract_tx_diff_obj(item)
            if err or diff is None:
                errs += 1
                continue
            patches.extend(_build_patches_from_prepost(i, diff, include_storage))
        return patches, {"hash": block_hash, "parentHash": parent_hash}, "block", errs
    except Exception:
        # Per-tx fallback
        patches = []
        errs = 0
        for i, txh in enumerate(txs):
            try:
                diff = pool.call("debug_traceTransaction", [txh, {"tracer":"prestateTracer","tracerConfig":tracer_cfg}])
                patches.extend(_build_patches_from_prepost(i, diff, include_storage))
            except Exception:
                errs += 1
        return patches, {"hash": block_hash, "parentHash": parent_hash}, "per-tx", errs
