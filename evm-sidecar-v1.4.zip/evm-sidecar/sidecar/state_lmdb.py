from __future__ import annotations
import os
from typing import Any, Dict, Iterable
import lmdb
from .codec import Patch, TAG_BALANCE, TAG_NONCE, TAG_STORAGE, hex_to_bytes, int_from_hex, H, bytes_to_hex

class LMDBState:
    """
    accounts db:
      b"b"+addr20 => 32-byte balance
      b"n"+addr20 => 8-byte nonce
    storage db:
      addr20||slot32 => 32-byte value
    """
    def __init__(self, path: str, map_size_bytes: int = 8 * 1024**3):
        os.makedirs(path, exist_ok=True)
        self.path = path
        self.env = lmdb.open(
            path,
            map_size=map_size_bytes,
            max_dbs=4,
            subdir=True,
            lock=True,
            sync=True,
            writemap=False,
            metasync=True
        )
        self.db_accounts = self.env.open_db(b"accounts")
        self.db_storage = self.env.open_db(b"storage")

    def _k_bal(self, addr: str) -> bytes:
        return b"b" + hex_to_bytes(addr, 20)

    def _k_nonce(self, addr: str) -> bytes:
        return b"n" + hex_to_bytes(addr, 20)

    def _k_store(self, addr: str, slot: str) -> bytes:
        return hex_to_bytes(addr, 20) + hex_to_bytes(slot, 32)

    def apply(self, patches: Iterable[Patch]) -> None:
        with self.env.begin(write=True, db=self.db_accounts) as txa, self.env.begin(write=True, db=self.db_storage) as txs:
            for p in patches:
                if p.tag == TAG_BALANCE:
                    if p.post_value is None:
                        txa.delete(self._k_bal(p.address))
                    else:
                        txa.put(self._k_bal(p.address), hex_to_bytes(p.post_value, 32))
                elif p.tag == TAG_NONCE:
                    if p.post_value is None:
                        txa.delete(self._k_nonce(p.address))
                    else:
                        n = int_from_hex(p.post_value)
                        txa.put(self._k_nonce(p.address), int(n).to_bytes(8, "big"))
                elif p.tag == TAG_STORAGE:
                    assert p.slot is not None
                    k = self._k_store(p.address, p.slot)
                    if p.post_value is None or int_from_hex(p.post_value) == 0:
                        txs.delete(k)
                    else:
                        txs.put(k, hex_to_bytes(p.post_value, 32))
                else:
                    raise ValueError(f"unknown tag {p.tag}")

    def stats(self) -> Dict[str, Any]:
        st = self.env.stat()
        info = self.env.info()
        size = 0
        for root, _, files in os.walk(self.path):
            for fn in files:
                fp = os.path.join(root, fn)
                try:
                    size += os.path.getsize(fp)
                except OSError:
                    pass
        return {"lmdb_stat": st, "lmdb_info": info, "disk_bytes": size}

    def commitment(self) -> str:
        # Sidecar commitment for debugging/progress (NOT Ethereum MPT root)
        acc = b""
        with self.env.begin(write=False, db=self.db_accounts) as tx:
            for k, v in tx.cursor():
                acc = H(acc + H(b"A" + k + v))
        with self.env.begin(write=False, db=self.db_storage) as tx:
            for k, v in tx.cursor():
                acc = H(acc + H(b"S" + k + v))
        return bytes_to_hex(acc)
