from __future__ import annotations
import json, os, shutil, tempfile
from typing import Dict, Any, List

def ensure_dir(p: str) -> None:
    os.makedirs(p, exist_ok=True)

def chain_root(bundles_dir: str, chain_id: str) -> str:
    return os.path.join(bundles_dir, f"chain_{chain_id}")

def block_dir(bundles_dir: str, chain_id: str, block_no: int) -> str:
    return os.path.join(chain_root(bundles_dir, chain_id), f"block_{block_no:012d}")

def manifest_path(bundles_dir: str, chain_id: str, block_no: int) -> str:
    return os.path.join(block_dir(bundles_dir, chain_id, block_no), "manifest.json")

def shard_path(bundles_dir: str, chain_id: str, block_no: int, shard_id: int) -> str:
    return os.path.join(block_dir(bundles_dir, chain_id, block_no), f"shard_{shard_id:03d}.bin")

def write_bundle_atomic(
    bundles_dir: str,
    chain_id: str,
    block_no: int,
    block_hash: str,
    parent_hash: str,
    compressor: str,
    hash_name: str,
    mac_root_hex: str,
    shard_blobs: Dict[int, bytes],
    shard_hashes_hex: Dict[int, str],
    meta: Dict[str, Any],
    receipt: Dict[str, Any] | None = None,
) -> None:
    """
    Crash-safe writer:
      - write everything into temp dir
      - fsync manifest
      - rename into place atomically
    """
    target = block_dir(bundles_dir, chain_id, block_no)
    ensure_dir(chain_root(bundles_dir, chain_id))
    tmp_parent = os.path.join(chain_root(bundles_dir, chain_id), ".tmp")
    ensure_dir(tmp_parent)

    tmp = tempfile.mkdtemp(prefix=f"block_{block_no:012d}_", dir=tmp_parent)
    try:
        shards: Dict[str, Any] = {}
        for sid, blob in shard_blobs.items():
            sp = os.path.join(tmp, f"shard_{sid:03d}.bin")
            with open(sp, "wb") as f:
                f.write(blob)
            shards[str(sid)] = {"file": os.path.basename(sp), "bytes": len(blob), "hash": shard_hashes_hex[sid]}

        man = {
            "version": "evm-sidecar-v1.2",
            "chainId": str(chain_id),
            "blockNo": int(block_no),
            "blockHash": block_hash,
            "parentHash": parent_hash,
            "compressor": compressor,
            "hash": hash_name,
            "macV1MerkleRoot": mac_root_hex,
            "shards": shards,
            "meta": meta,
        }
        if receipt is not None:
            man["receipt"] = receipt

        mp = os.path.join(tmp, "manifest.json")
        with open(mp, "w", encoding="utf-8") as f:
            json.dump(man, f, indent=2, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())

        # Replace target atomically
        if os.path.exists(target):
            shutil.rmtree(target)
        os.replace(tmp, target)  # atomic rename
        tmp = ""  # consumed
    finally:
        if tmp and os.path.exists(tmp):
            shutil.rmtree(tmp, ignore_errors=True)

def read_manifest(bundles_dir: str, chain_id: str, block_no: int) -> Dict[str, Any]:
    with open(manifest_path(bundles_dir, chain_id, block_no), "r", encoding="utf-8") as f:
        return json.load(f)

def read_shard(bundles_dir: str, chain_id: str, block_no: int, shard_id: int) -> bytes:
    with open(shard_path(bundles_dir, chain_id, block_no, shard_id), "rb") as f:
        return f.read()

def list_blocks(bundles_dir: str, chain_id: str) -> List[int]:
    base = chain_root(bundles_dir, chain_id)
    if not os.path.isdir(base):
        return []
    out = []
    for name in os.listdir(base):
        if name.startswith("block_"):
            try:
                out.append(int(name.split("_")[1]))
            except Exception:
                pass
    return sorted(out)

def prune_keep_last(bundles_dir: str, chain_id: str, keep: int) -> int:
    blocks = list_blocks(bundles_dir, chain_id)
    if keep <= 0 or len(blocks) <= keep:
        return 0
    doomed = blocks[:-keep]
    removed = 0
    for b in doomed:
        d = block_dir(bundles_dir, chain_id, b)
        try:
            shutil.rmtree(d)
            removed += 1
        except Exception:
            pass
    return removed

def delete_blocks_after(bundles_dir: str, chain_id: str, block_no: int) -> int:
    blocks = list_blocks(bundles_dir, chain_id)
    doomed = [b for b in blocks if b > block_no]
    removed = 0
    for b in doomed:
        d = block_dir(bundles_dir, chain_id, b)
        try:
            shutil.rmtree(d)
            removed += 1
        except Exception:
            pass
    return removed
