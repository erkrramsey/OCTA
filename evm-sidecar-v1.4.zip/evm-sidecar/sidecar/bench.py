from __future__ import annotations
import argparse, os, time, json, statistics
from typing import Dict, Any, List
import requests

from .codec import decompress, decode_patch_list, Patch, empty_patch_list_raw, H
from .state_lmdb import LMDBState
from .merkle import merkle_root
from .fast_replay import cache_list_blocks, rollback as fr_rollback

def fetch_manifest(relay: str, chain_id: str, block_no: int) -> Dict[str, Any]:
    r = requests.get(f"{relay}/v1/chain/{chain_id}/block/{block_no}/manifest", timeout=60)
    r.raise_for_status()
    return r.json()

def fetch_shard(relay: str, chain_id: str, block_no: int, shard_id: int) -> bytes:
    r = requests.get(f"{relay}/v1/chain/{chain_id}/block/{block_no}/shard/{shard_id}", timeout=120)
    if r.status_code == 404:
        return b""
    r.raise_for_status()
    return r.content

def shard_leaf(shard_id: int, raw: bytes) -> bytes:
    return H(b"shard|" + shard_id.to_bytes(2, "big") + H(raw))

def bench_replay(relay: str, chain_id: str, state_dir: str, start: int, count: int, map_gb: int, verify_mac: bool) -> Dict[str, Any]:
    st = LMDBState(state_dir, map_size_bytes=int(map_gb)*1024**3)
    empty_raw = empty_patch_list_raw()
    empty_leaf = [shard_leaf(i, empty_raw) for i in range(256)]

    block_times: List[float] = []
    bytes_dl = 0
    patches_total = 0
    nonempty_total = 0

    t0 = time.perf_counter()
    for b in range(start, start + count):
        bt0 = time.perf_counter()
        man = fetch_manifest(relay, chain_id, b)
        comp = man["compressor"]
        sparse = man.get("shards", {}) or {}
        leaves = empty_leaf[:]
        patches: List[Patch] = []

        for sid_str, meta in sparse.items():
            sid = int(sid_str)
            blob = fetch_shard(relay, chain_id, b, sid)
            if not blob:
                continue
            bytes_dl += len(blob)
            raw = decompress(comp, blob)
            leaves[sid] = shard_leaf(sid, raw)
            patches.extend(decode_patch_list(raw))

        if verify_mac:
            got = merkle_root(leaves)
            want = bytes.fromhex(man["macV1MerkleRoot"][2:])
            if got != want:
                raise RuntimeError(f"MAC mismatch at block {b}")

        patches.sort(key=lambda p: p.sort_key())
        st.apply(patches)

        bt1 = time.perf_counter()
        block_times.append(bt1 - bt0)
        patches_total += len(patches)
        nonempty_total += len(sparse)

    t1 = time.perf_counter()
    elapsed = t1 - t0

    def pct(xs: List[float], p: float) -> float:
        if not xs: return 0.0
        xs2 = sorted(xs)
        k = int(round((p/100.0)*(len(xs2)-1)))
        return xs2[k]

    return {
        "mode": "replay",
        "relay": relay,
        "chainId": chain_id,
        "start": start,
        "count": count,
        "verifyMac": bool(verify_mac),
        "elapsed_s": elapsed,
        "blocks_per_s": (count / elapsed) if elapsed > 0 else 0.0,
        "per_block_s": {
            "mean": statistics.mean(block_times) if block_times else 0.0,
            "p50": pct(block_times, 50),
            "p95": pct(block_times, 95),
            "p99": pct(block_times, 99),
        },
        "download_bytes": bytes_dl,
        "download_bytes_per_block": bytes_dl / max(1, count),
        "patches_total": patches_total,
        "patches_per_block": patches_total / max(1, count),
        "nonempty_shards_per_block": nonempty_total / max(1, count),
        "state_commit": st.commitment(),
        "state_stats": st.stats(),
    }

def bench_reorg(state_dir: str, chain_id: str, rollback_n: int) -> Dict[str, Any]:
    st = LMDBState(state_dir)
    cached = cache_list_blocks(state_dir, chain_id)
    if not cached:
        raise RuntimeError("No cached blocks in state_dir/sidecar_cache. Run fast_replay first.")
    t0 = time.perf_counter()
    fr_rollback(st, state_dir, chain_id, rollback_n)
    t1 = time.perf_counter()
    return {
        "mode": "reorg_rollback",
        "chainId": chain_id,
        "rollback_n": rollback_n,
        "elapsed_s": (t1 - t0),
        "state_commit": st.commitment(),
        "cached_blocks": len(cached),
        "cached_range": [min(cached), max(cached)],
    }

def main():
    ap = argparse.ArgumentParser(prog="sidecar.bench")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("replay", help="Measure Fast Replay apply throughput from a relay")
    p1.add_argument("--relay", default=os.environ.get("SIDECAR_RELAY_URL","http://127.0.0.1:8080"))
    p1.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    p1.add_argument("--state-dir", default=os.environ.get("SIDECAR_STATE_DIR","./bench_state_lmdb"))
    p1.add_argument("--start", type=int, required=True)
    p1.add_argument("--count", type=int, default=200)
    p1.add_argument("--map-size-gb", type=int, default=8)
    p1.add_argument("--verify-mac", action="store_true")

    p2 = sub.add_parser("reorg", help="Measure rollback speed using cached blocks")
    p2.add_argument("--state-dir", default=os.environ.get("SIDECAR_STATE_DIR","./state_lmdb"))
    p2.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    p2.add_argument("--rollback", type=int, required=True)

    p3 = sub.add_parser("report", help="Run replay then rollback and print combined report")
    p3.add_argument("--relay", default=os.environ.get("SIDECAR_RELAY_URL","http://127.0.0.1:8080"))
    p3.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    p3.add_argument("--start", type=int, required=True)
    p3.add_argument("--count", type=int, default=200)
    p3.add_argument("--rollback", type=int, default=10)
    p3.add_argument("--verify-mac", action="store_true")
    p3.add_argument("--state-dir", default=os.environ.get("SIDECAR_STATE_DIR","./bench_state_lmdb"))

    args = ap.parse_args()

    if args.cmd == "replay":
        rep = bench_replay(args.relay, args.chain_id, args.state_dir, args.start, args.count, args.map_size_gb, args.verify_mac)
        print(json.dumps(rep, indent=2))
        return
    if args.cmd == "reorg":
        rep = bench_reorg(args.state_dir, args.chain_id, args.rollback)
        print(json.dumps(rep, indent=2))
        return
    if args.cmd == "report":
        rep1 = bench_replay(args.relay, args.chain_id, args.state_dir, args.start, args.count, 8, args.verify_mac)
        # To test rollback, we need cache; easiest: run fast_replay separately for caching
        # Here we just include a placeholder if cache doesn't exist
        rep = {"replay": rep1, "note": "Run: python -m sidecar.fast_replay --from-block <start> --count <count> to populate rollback cache, then python -m sidecar.bench reorg --rollback <N>"}
        print(json.dumps(rep, indent=2))
        return

if __name__ == "__main__":
    main()
