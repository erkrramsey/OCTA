from __future__ import annotations
import binascii
import gzip
import hashlib
from dataclasses import dataclass
from typing import Optional, Tuple, List

# -----------------------------
# Hash (blake3 preferred)
# -----------------------------
try:
    from blake3 import blake3  # type: ignore
    def H(data: bytes) -> bytes:
        return blake3(data).digest()
    HASH_NAME = "blake3"
except Exception:
    def H(data: bytes) -> bytes:
        return hashlib.sha256(data).digest()
    HASH_NAME = "sha256"

# -----------------------------
# Compression (zstd preferred)
# -----------------------------
try:
    import zstandard as zstd  # type: ignore
    _ZSTD = True
except Exception:
    zstd = None
    _ZSTD = False

def compress(raw: bytes, level: int = 8) -> Tuple[str, bytes]:
    if _ZSTD:
        c = zstd.ZstdCompressor(level=level)
        return ("zstd", c.compress(raw))
    return ("gzip", gzip.compress(raw, compresslevel=min(9, max(1, level))))

def decompress(kind: str, blob: bytes) -> bytes:
    if kind == "zstd":
        if not _ZSTD:
            raise RuntimeError("zstandard not installed but bundle is zstd")
        d = zstd.ZstdDecompressor()
        return d.decompress(blob)
    if kind == "gzip":
        return gzip.decompress(blob)
    raise ValueError(f"unknown compression: {kind}")

# -----------------------------
# Hex helpers
# -----------------------------
def strip_0x(s: str) -> str:
    return s[2:] if isinstance(s, str) and s.startswith("0x") else s

def bytes_to_hex(b: bytes) -> str:
    return "0x" + b.hex()

def hex_to_bytes(s: str, expected_len: Optional[int] = None) -> bytes:
    s2 = strip_0x(s or "")
    if s2 == "":
        b = b""
    else:
        if len(s2) % 2 == 1:
            s2 = "0" + s2
        b = binascii.unhexlify(s2)
    if expected_len is not None:
        if len(b) > expected_len:
            raise ValueError(f"hex too long: got {len(b)} expected <= {expected_len}")
        b = b.rjust(expected_len, b"\x00")
    return b

def norm_addr(addr: str) -> str:
    a = "0x" + strip_0x(addr).lower().rjust(40, "0")
    if len(strip_0x(a)) != 40:
        raise ValueError(f"bad address: {addr}")
    return a

def norm_slot(slot: str) -> str:
    return "0x" + strip_0x(slot).lower().rjust(64, "0")

def norm_word(word: str) -> str:
    return "0x" + strip_0x(word).lower().rjust(64, "0")

def int_from_hex(s: str) -> int:
    return int(strip_0x(s or "0"), 16)

# -----------------------------
# Patch model
# -----------------------------
TAG_BALANCE = 1
TAG_NONCE   = 2
TAG_STORAGE = 3

@dataclass(frozen=True)
class Patch:
    """
    Reversible patch.
    pre_value/post_value are 32-byte words hex (or None => absent/cleared).
    """
    tx_index: int
    address: str
    tag: int
    slot: Optional[str]
    pre_value: Optional[str]
    post_value: Optional[str]

    def shard(self) -> int:
        return hex_to_bytes(self.address, 20)[0]

    def sort_key(self):
        return (self.address, self.tag, self.slot or "", self.tx_index)

    def invert(self) -> "Patch":
        return Patch(self.tx_index, self.address, self.tag, self.slot, self.post_value, self.pre_value)

    def encode(self) -> bytes:
        out = bytearray()
        out += int(self.tx_index).to_bytes(4, "big")
        out += int(self.tag).to_bytes(1, "big")
        out += hex_to_bytes(self.address, 20)

        if self.slot is None:
            out += b"\x00"
        else:
            out += b"\x01" + hex_to_bytes(self.slot, 32)

        if self.pre_value is None:
            out += b"\x00"
        else:
            out += b"\x01" + hex_to_bytes(self.pre_value, 32)

        if self.post_value is None:
            out += b"\x00"
        else:
            out += b"\x01" + hex_to_bytes(self.post_value, 32)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes, off: int) -> Tuple["Patch", int]:
        tx_index = int.from_bytes(buf[off:off+4], "big"); off += 4
        tag = buf[off]; off += 1
        addr = bytes_to_hex(buf[off:off+20]); off += 20

        has_slot = buf[off]; off += 1
        slot = None
        if has_slot:
            slot = bytes_to_hex(buf[off:off+32]); off += 32

        has_pre = buf[off]; off += 1
        pre = None
        if has_pre:
            pre = bytes_to_hex(buf[off:off+32]); off += 32

        has_post = buf[off]; off += 1
        post = None
        if has_post:
            post = bytes_to_hex(buf[off:off+32]); off += 32

        return Patch(
            tx_index=int(tx_index),
            address=norm_addr(addr),
            tag=int(tag),
            slot=norm_slot(slot) if slot else None,
            pre_value=norm_word(pre) if pre else None,
            post_value=norm_word(post) if post else None,
        ), off

def encode_patch_list(patches: List[Patch]) -> bytes:
    patches.sort(key=lambda p: p.sort_key())
    out = bytearray()
    out += len(patches).to_bytes(4, "big")
    for p in patches:
        out += p.encode()
    return bytes(out)

def decode_patch_list(buf: bytes) -> List[Patch]:
    if len(buf) < 4:
        return []
    off = 0
    n = int.from_bytes(buf[off:off+4], "big"); off += 4
    out: List[Patch] = []
    for _ in range(n):
        p, off = Patch.decode(buf, off)
        out.append(p)
    return out

def empty_patch_list_raw() -> bytes:
    # Canonical empty patch list encoding (u32 count == 0)
    return (0).to_bytes(4, "big")
