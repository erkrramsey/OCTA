from __future__ import annotations
from typing import List
from .codec import H

def merkle_root(leaves: List[bytes]) -> bytes:
    if not leaves:
        return H(b"")
    level = [H(b"leaf|" + x) for x in leaves]
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            a = level[i]
            b = level[i+1] if i+1 < len(level) else level[i]
            nxt.append(H(b"node|" + a + b))
        level = nxt
    return level[0]

def merkle_proof_from_leaves(leaves: List[bytes], index: int) -> List[bytes]:
    if not leaves:
        return []
    lvl = [H(b"leaf|" + x) for x in leaves]
    idx = index
    proof: List[bytes] = []
    while len(lvl) > 1:
        sib = (lvl[idx+1] if idx+1 < len(lvl) else lvl[idx]) if (idx % 2 == 0) else lvl[idx-1]
        proof.append(sib)
        nxt = []
        for i in range(0, len(lvl), 2):
            a = lvl[i]
            b = lvl[i+1] if i+1 < len(lvl) else lvl[i]
            nxt.append(H(b"node|" + a + b))
        lvl = nxt
        idx //= 2
    return proof

def merkle_verify_leaf(leaf: bytes, index: int, proof: List[bytes], root: bytes) -> bool:
    h = H(b"leaf|" + leaf)
    idx = index
    for sib in proof:
        if idx % 2 == 0:
            h = H(b"node|" + h + sib)
        else:
            h = H(b"node|" + sib + h)
        idx //= 2
    return h == root
