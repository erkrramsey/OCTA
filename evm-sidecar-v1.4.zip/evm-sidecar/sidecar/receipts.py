from __future__ import annotations
import os, time, json, base64, hashlib, hmac
from dataclasses import dataclass
from typing import Optional, Literal, Dict, Any

Algo = Literal["ed25519", "hmac-sha256"]

def _b64e(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")

def _b64d(s: str) -> bytes:
    pad = "=" * ((4 - (len(s) % 4)) % 4)
    return base64.urlsafe_b64decode((s + pad).encode("ascii"))

@dataclass
class Receipt:
    version: str
    algo: Algo
    relay_id: str
    chain_id: str
    block_no: int
    block_hash: str
    mac_root: str
    produced_at_ms: int
    sig: str  # base64url

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": self.version,
            "algo": self.algo,
            "relayId": self.relay_id,
            "chainId": self.chain_id,
            "blockNo": self.block_no,
            "blockHash": self.block_hash,
            "macV1MerkleRoot": self.mac_root,
            "producedAtMs": self.produced_at_ms,
            "sig": self.sig,
        }

def receipt_message(chain_id: str, block_no: int, block_hash: str, mac_root: str, produced_at_ms: int) -> bytes:
    return (
        b"sidecar_receipt_v1|"
        + str(chain_id).encode("utf-8") + b"|"
        + str(int(block_no)).encode("utf-8") + b"|"
        + block_hash.encode("utf-8") + b"|"
        + mac_root.encode("utf-8") + b"|"
        + str(int(produced_at_ms)).encode("utf-8")
    )

class ReceiptSigner:
    """
    Signs receipts. Prefers Ed25519 but can fall back to HMAC-SHA256.

    Key storage:
      - SIDECAR_KEY_PATH (default: <bundles_dir>/keys/sidecar_key.json)

    sidecar_key.json:

    Ed25519:
      {"algo":"ed25519","relayId":"relay-1","sk":"<b64url 32>","pk":"<b64url 32>"}

    HMAC:
      {"algo":"hmac-sha256","relayId":"relay-1","key":"<b64url bytes>"}
    """
    def __init__(self, bundles_dir: str, key_path: Optional[str] = None):
        self.bundles_dir = bundles_dir
        self.key_path = key_path or os.environ.get("SIDECAR_KEY_PATH") or os.path.join(bundles_dir, "keys", "sidecar_key.json")
        os.makedirs(os.path.dirname(self.key_path), exist_ok=True)

        self.algo: Algo
        self.relay_id: str
        self._sk: Optional[bytes] = None
        self._pk: Optional[bytes] = None
        self._hmac_key: Optional[bytes] = None
        self._ed_priv = None

        self._load_or_create()

    def _load_or_create(self) -> None:
        if os.path.exists(self.key_path):
            with open(self.key_path, "r", encoding="utf-8") as f:
                j = json.load(f)
            algo = j.get("algo", "ed25519")
            self.relay_id = j.get("relayId", "relay-1")
            if algo == "ed25519":
                self.algo = "ed25519"
                self._sk = _b64d(j["sk"])
                self._pk = _b64d(j["pk"]) if "pk" in j else None
            else:
                self.algo = "hmac-sha256"
                self._hmac_key = _b64d(j["key"])
            self._init_crypto()
            # Backfill pk if missing
            if self.algo == "ed25519" and self._pk is None:
                self._pk = self.public_key_bytes()
                j["pk"] = _b64e(self._pk)
                with open(self.key_path, "w", encoding="utf-8") as f:
                    json.dump(j, f, indent=2, sort_keys=True)
            return

        self.relay_id = os.environ.get("SIDECAR_RELAY_ID", "relay-1")
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # type: ignore
            sk = os.urandom(32)
            self.algo = "ed25519"
            self._sk = sk
            self._init_crypto()
            pk = self.public_key_bytes()
            self._pk = pk
            with open(self.key_path, "w", encoding="utf-8") as f:
                json.dump({"algo":"ed25519","relayId":self.relay_id,"sk":_b64e(sk),"pk":_b64e(pk)}, f, indent=2, sort_keys=True)
        except Exception:
            key = os.urandom(32)
            self.algo = "hmac-sha256"
            self._hmac_key = key
            with open(self.key_path, "w", encoding="utf-8") as f:
                json.dump({"algo":"hmac-sha256","relayId":self.relay_id,"key":_b64e(key)}, f, indent=2, sort_keys=True)

    def _init_crypto(self) -> None:
        if self.algo == "ed25519":
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey  # type: ignore
            assert self._sk is not None
            self._ed_priv = Ed25519PrivateKey.from_private_bytes(self._sk)

    def public_key_bytes(self) -> bytes:
        if self.algo != "ed25519":
            raise RuntimeError("No public key for non-ed25519 signer")
        from cryptography.hazmat.primitives import serialization  # type: ignore
        pub = self._ed_priv.public_key()
        return pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

    def public_key_b64(self) -> Optional[str]:
        if self.algo != "ed25519":
            return None
        if self._pk is None:
            self._pk = self.public_key_bytes()
        return _b64e(self._pk)

    def sign(self, chain_id: str, block_no: int, block_hash: str, mac_root: str, produced_at_ms: Optional[int] = None) -> Receipt:
        ts = int(produced_at_ms if produced_at_ms is not None else time.time() * 1000)
        msg = receipt_message(chain_id, block_no, block_hash, mac_root, ts)
        if self.algo == "ed25519":
            sig = self._ed_priv.sign(msg)
        else:
            assert self._hmac_key is not None
            sig = hmac.new(self._hmac_key, msg, hashlib.sha256).digest()
        return Receipt(
            version="sidecar_receipt_v1",
            algo=self.algo,
            relay_id=self.relay_id,
            chain_id=str(chain_id),
            block_no=int(block_no),
            block_hash=block_hash,
            mac_root=mac_root,
            produced_at_ms=ts,
            sig=_b64e(sig),
        )

def verify_receipt(receipt: Dict[str, Any], pub_or_key: str) -> bool:
    algo = receipt.get("algo")
    msg = receipt_message(
        receipt["chainId"], int(receipt["blockNo"]), receipt["blockHash"], receipt["macV1MerkleRoot"], int(receipt["producedAtMs"])
    )
    sig = _b64d(receipt["sig"])
    if algo == "ed25519":
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey  # type: ignore
        pk = _b64d(pub_or_key)
        try:
            Ed25519PublicKey.from_public_bytes(pk).verify(sig, msg)
            return True
        except Exception:
            return False
    if algo == "hmac-sha256":
        key = _b64d(pub_or_key)
        expect = hmac.new(key, msg, hashlib.sha256).digest()
        return hmac.compare_digest(sig, expect)
    return False
