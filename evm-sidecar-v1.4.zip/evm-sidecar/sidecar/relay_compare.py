from __future__ import annotations
import argparse, os, json
from typing import Dict, Any, List
import requests

def mac(relay: str, chain_id: str, block_no: int) -> str:
    r = requests.get(f"{relay}/v1/chain/{chain_id}/block/{block_no}/mac", timeout=30)
    r.raise_for_status()
    return r.json()["macV1MerkleRoot"]

def main():
    ap = argparse.ArgumentParser(prog="sidecar.relay_compare")
    ap.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    ap.add_argument("--relays", required=True, help="comma-separated relay base URLs")
    ap.add_argument("--start", type=int, required=True)
    ap.add_argument("--count", type=int, default=200)
    args = ap.parse_args()

    relays = [r.strip().rstrip("/") for r in args.relays.split(",") if r.strip()]
    if len(relays) < 2:
        raise SystemExit("Need at least 2 relays to compare")

    mismatches: List[Dict[str, Any]] = []
    for b in range(args.start, args.start + args.count):
        macs = {}
        for rly in relays:
            try:
                macs[rly] = mac(rly, args.chain_id, b)
            except Exception as e:
                macs[rly] = f"ERROR:{e}"
        vals = set(macs.values())
        if len(vals) != 1:
            mismatches.append({"blockNo": b, "macs": macs})

    out = {
        "chainId": args.chain_id,
        "relays": relays,
        "start": args.start,
        "count": args.count,
        "mismatchCount": len(mismatches),
        "mismatches": mismatches[:50],
        "note": "If mismatchCount > 0, at least one relay is wrong OR they used different trace semantics."
    }
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
