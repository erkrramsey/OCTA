from __future__ import annotations
import argparse, os, json
from typing import Dict, Any, List
import requests

def mac(relay: str, chain_id: str, block_no: int) -> str:
    r = requests.get(f"{relay}/v1/chain/{chain_id}/block/{block_no}/mac", timeout=30)
    r.raise_for_status()
    return r.json()["macV1MerkleRoot"]

def main():
    ap = argparse.ArgumentParser(prog="sidecar.quorum")
    ap.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    ap.add_argument("--relays", required=True, help="comma-separated relay base URLs")
    ap.add_argument("--start", type=int, required=True)
    ap.add_argument("--count", type=int, default=200)
    ap.add_argument("--m", type=int, default=2, help="M-of-N threshold")
    args = ap.parse_args()

    relays = [r.strip().rstrip("/") for r in args.relays.split(",") if r.strip()]
    n = len(relays)
    if n < 2:
        raise SystemExit("Need at least 2 relays")
    m = max(1, min(args.m, n))

    failures: List[Dict[str, Any]] = []
    for b in range(args.start, args.start + args.count):
        macs: Dict[str, str] = {}
        for rly in relays:
            try:
                macs[rly] = mac(rly, args.chain_id, b)
            except Exception as e:
                macs[rly] = f"ERROR:{e}"
        # count votes
        counts: Dict[str, int] = {}
        for v in macs.values():
            counts[v] = counts.get(v, 0) + 1
        winner, win_ct = max(counts.items(), key=lambda kv: kv[1])
        if win_ct < m:
            failures.append({"blockNo": b, "winner": winner, "winnerVotes": win_ct, "macs": macs})

    out = {
        "chainId": args.chain_id,
        "relays": relays,
        "start": args.start,
        "count": args.count,
        "threshold": f"{m}-of-{n}",
        "failedBlocks": len(failures),
        "examples": failures[:25],
        "note": "If failedBlocks>0, no MAC achieved quorum for those blocks (or relays errored)."
    }
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
