from __future__ import annotations
import threading, time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import requests

class RpcError(Exception):
    pass

@dataclass
class _EndpointState:
    url: str
    failures: int = 0
    open_until: float = 0.0
    tokens: float = 0.0
    last_refill: float = 0.0

class RpcPool:
    """
    Multi-endpoint JSON-RPC with:
      - endpoint rotation on failure
      - retries per call
      - thread-safe request ids
      - per-endpoint token-bucket rate limiting
      - circuit breaker (trip after N failures; cool-down)
    """

    def __init__(
        self,
        urls: List[str],
        timeout_s: float = 60.0,
        retries: int = 2,
        rps: float = 50.0,
        burst: int = 50,
        fail_threshold: int = 5,
        cooldown_s: float = 10.0,
    ):
        urls = [u.strip() for u in urls if u and u.strip()]
        if not urls:
            raise ValueError("No RPC URLs provided")
        self.timeout_s = float(timeout_s)
        self.retries = max(0, int(retries))
        self.rps = max(0.1, float(rps))
        self.burst = max(1, int(burst))
        self.fail_threshold = max(1, int(fail_threshold))
        self.cooldown_s = max(0.5, float(cooldown_s))

        now = time.monotonic()
        self._eps: List[_EndpointState] = []
        for u in urls:
            self._eps.append(_EndpointState(url=u, failures=0, open_until=0.0, tokens=float(self.burst), last_refill=now))

        self._lock = threading.Lock()
        self._idx = 0
        self._id = 1

    def _next_id(self) -> int:
        with self._lock:
            rid = self._id
            self._id += 1
            return rid

    def _rotate(self) -> None:
        with self._lock:
            self._idx = (self._idx + 1) % len(self._eps)

    def _refill(self, ep: _EndpointState, now: float) -> None:
        dt = max(0.0, now - ep.last_refill)
        if dt <= 0:
            return
        ep.tokens = min(float(self.burst), ep.tokens + dt * self.rps)
        ep.last_refill = now

    def _pick_endpoint(self) -> _EndpointState:
        """
        Picks an endpoint that isn't circuit-open and has tokens (or will wait briefly).
        """
        deadline = time.monotonic() + 2.0  # small wait window to smooth bursts
        while True:
            with self._lock:
                ep = self._eps[self._idx % len(self._eps)]
            now = time.monotonic()
            if ep.open_until > now:
                self._rotate()
                continue
            self._refill(ep, now)
            if ep.tokens >= 1.0:
                ep.tokens -= 1.0
                return ep
            if time.monotonic() > deadline:
                # allow overdraw after waiting; better than deadlock
                ep.tokens = max(0.0, ep.tokens - 1.0)
                return ep
            time.sleep(0.01)

    def _record_success(self, ep: _EndpointState) -> None:
        ep.failures = 0

    def _record_failure(self, ep: _EndpointState) -> None:
        ep.failures += 1
        if ep.failures >= self.fail_threshold:
            ep.open_until = time.monotonic() + self.cooldown_s
            ep.failures = 0  # reset after trip

    def call(self, method: str, params: list) -> Any:
        last_err: Optional[Exception] = None
        attempts = 1 + self.retries
        for _ in range(attempts):
            ep = self._pick_endpoint()
            payload = {"jsonrpc":"2.0","id":self._next_id(),"method":method,"params":params}
            try:
                r = requests.post(ep.url, json=payload, timeout=self.timeout_s)
                r.raise_for_status()
                j = r.json()
                if "error" in j:
                    raise RpcError(str(j["error"]))
                self._record_success(ep)
                return j["result"]
            except Exception as e:
                last_err = e
                self._record_failure(ep)
                self._rotate()
        raise RpcError(f"RPC call failed after {attempts} attempts: {method} :: {last_err}")

    def endpoint(self) -> str:
        with self._lock:
            return self._eps[self._idx % len(self._eps)].url

    def health(self) -> Dict[str, Any]:
        now = time.monotonic()
        out = []
        for ep in self._eps:
            out.append({
                "url": ep.url,
                "open": bool(ep.open_until > now),
                "openUntil": ep.open_until,
                "tokens": ep.tokens,
            })
        return {
            "rps": self.rps,
            "burst": self.burst,
            "failThreshold": self.fail_threshold,
            "cooldownS": self.cooldown_s,
            "endpoints": out
        }
