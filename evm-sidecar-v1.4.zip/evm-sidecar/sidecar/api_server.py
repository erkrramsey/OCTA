from __future__ import annotations
import os, threading
from fastapi import FastAPI, HTTPException, Response, Request
from fastapi.responses import FileResponse
import uvicorn

from .bundle_store import read_manifest, shard_path
from .relay_worker import run_forever
from .codec import H, empty_patch_list_raw
from .merkle import merkle_proof_from_leaves
from .receipts import ReceiptSigner

app = FastAPI(title="EVM SideCar Relay", version="0.1.4")

BUNDLES_DIR = os.environ.get("SIDECAR_BUNDLES_DIR", "./bundles")

def _dense_leaves_from_manifest(man: dict) -> list[bytes]:
    empty_raw = empty_patch_list_raw()
    leaves = [H(b"shard|" + i.to_bytes(2, "big") + H(empty_raw)) for i in range(256)]
    shards = man.get("shards", {}) or {}
    for sid_str, meta in shards.items():
        sid = int(sid_str)
        leaves[sid] = bytes.fromhex(meta["hash"][2:])
    return leaves

def _etag(v: str) -> str:
    return f"\"{v}\""

def _maybe_304(req: Request, etag_value: str, response: Response) -> bool:
    inm = req.headers.get("if-none-match")
    response.headers["ETag"] = _etag(etag_value)
    if inm and inm.strip() == _etag(etag_value):
        response.status_code = 304
        return True
    return False

@app.get("/health")
def health():
    return {"ok": True, "brand": "EVM SideCar", "feature": "Fast Replay", "infra": "SideCar L2 infra"}

@app.get("/v1/relay/info")
def relay_info(req: Request, response: Response):
    signer = ReceiptSigner(BUNDLES_DIR)
    et = f"{signer.relay_id}:{signer.algo}:{signer.public_key_b64() or ''}"
    if _maybe_304(req, et, response):
        return None
    return {
        "relayId": signer.relay_id,
        "algo": signer.algo,
        "publicKeyB64": signer.public_key_b64(),
        "note": "If algo==ed25519, clients can verify receipts with publicKeyB64. If algo==hmac-sha256, key is not public."
    }

@app.get("/v1/chain/{chainId}/block/{blockNo}/manifest")
def get_manifest(chainId: str, blockNo: int, req: Request, response: Response):
    try:
        man = read_manifest(BUNDLES_DIR, chainId, blockNo)
        if _maybe_304(req, man["macV1MerkleRoot"], response):
            return None
        return man
    except Exception:
        raise HTTPException(status_code=404, detail="manifest not found")

@app.get("/v1/chain/{chainId}/block/{blockNo}/mac")
def get_mac(chainId: str, blockNo: int, req: Request, response: Response):
    try:
        man = read_manifest(BUNDLES_DIR, chainId, blockNo)
        if _maybe_304(req, man["macV1MerkleRoot"], response):
            return None
        return {"blockNo": blockNo, "chainId": chainId, "macV1MerkleRoot": man["macV1MerkleRoot"]}
    except Exception:
        raise HTTPException(status_code=404, detail="mac not found")

@app.get("/v1/chain/{chainId}/block/{blockNo}/receipt")
def get_receipt(chainId: str, blockNo: int, req: Request, response: Response):
    try:
        man = read_manifest(BUNDLES_DIR, chainId, blockNo)
        if "receipt" not in man:
            raise HTTPException(status_code=404, detail="receipt not found")
        sig = man["receipt"]["sig"]
        if _maybe_304(req, sig, response):
            return None
        return man["receipt"]
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=404, detail="receipt not found")

@app.get("/v1/chain/{chainId}/block/{blockNo}/shard/{shardId}")
def get_shard(chainId: str, blockNo: int, shardId: int, req: Request, response: Response):
    fp = shard_path(BUNDLES_DIR, chainId, blockNo, shardId)
    if not os.path.exists(fp):
        raise HTTPException(status_code=404, detail="shard not found (sparse: shard may be empty)")
    try:
        man = read_manifest(BUNDLES_DIR, chainId, blockNo)
        meta = (man.get("shards", {}) or {}).get(str(shardId))
        etag_value = meta["hash"] if meta and "hash" in meta else man["macV1MerkleRoot"]
    except Exception:
        etag_value = "0x0"
    if _maybe_304(req, etag_value, response):
        return None
    return FileResponse(
        fp,
        media_type="application/octet-stream",
        filename=os.path.basename(fp),
        headers={"ETag": _etag(etag_value)},
    )

@app.get("/v1/chain/{chainId}/block/{blockNo}/proof/{shardId}")
def get_proof(chainId: str, blockNo: int, shardId: int, req: Request, response: Response):
    if shardId < 0 or shardId > 255:
        raise HTTPException(status_code=400, detail="shardId must be 0..255")
    try:
        man = read_manifest(BUNDLES_DIR, chainId, blockNo)
        etv = man["macV1MerkleRoot"] + f":{shardId}"
        if _maybe_304(req, etv, response):
            return None
        leaves = _dense_leaves_from_manifest(man)
        proof = merkle_proof_from_leaves(leaves, shardId)
        response.headers["ETag"] = _etag(etv)
        return {
            "blockNo": blockNo,
            "chainId": chainId,
            "shardId": shardId,
            "macV1MerkleRoot": man["macV1MerkleRoot"],
            "leaf": "0x" + leaves[shardId].hex(),
            "proof": ["0x" + p.hex() for p in proof],
        }
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=404, detail="proof not found")

def main():
    t = threading.Thread(target=run_forever, daemon=True)
    t.start()

    host = os.environ.get("SIDECAR_HOST", "0.0.0.0")
    port = int(os.environ.get("SIDECAR_PORT", "8080"))
    uvicorn.run("sidecar.api_server:app", host=host, port=port, reload=False)

if __name__ == "__main__":
    main()
