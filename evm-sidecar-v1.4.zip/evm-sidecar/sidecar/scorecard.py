from __future__ import annotations
import argparse, os, json, time
from typing import Dict, Any
from .bench import bench_replay, bench_reorg

def main():
    ap = argparse.ArgumentParser(prog="sidecar.scorecard")
    ap.add_argument("--relay", default=os.environ.get("SIDECAR_RELAY_URL","http://127.0.0.1:8080"))
    ap.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    ap.add_argument("--start", type=int, required=True)
    ap.add_argument("--count", type=int, default=500)
    ap.add_argument("--rollback", type=int, default=50)
    ap.add_argument("--state-dir", default=os.environ.get("SIDECAR_STATE_DIR","./score_state_lmdb"))
    ap.add_argument("--verify-mac", action="store_true")
    args = ap.parse_args()

    t0 = time.perf_counter()
    replay = bench_replay(args.relay, args.chain_id, args.state_dir, args.start, args.count, 8, args.verify_mac)

    # Populate rollback cache: bench_replay does not cache. So we advise to run fast_replay separately, but for scorecard
    # we'll just report replay; rollback requires cache.
    # However, fast_replay caches by default; we can run it via subprocess for one shot.
    import subprocess, sys
    cmd = [sys.executable, "-m", "sidecar.fast_replay", "--from-block", str(args.start), "--count", str(args.count)]
    if args.verify_mac:
        cmd.append("--verify-mac")
    subprocess.run(cmd, check=True)

    reorg = bench_reorg(args.state_dir, args.chain_id, args.rollback)
    t1 = time.perf_counter()

    out: Dict[str, Any] = {
        "brand": "EVM SideCar",
        "feature": "Fast Replay",
        "infra": "SideCar L2 infra",
        "elapsed_total_s": (t1 - t0),
        "replay": replay,
        "reorgRollback": reorg,
        "headline": {
            "replay_blocks_per_s": replay["blocks_per_s"],
            "reorg_rollback_s": reorg["elapsed_s"],
            "download_bytes_per_block": replay["download_bytes_per_block"],
            "patches_per_block": replay["patches_per_block"],
        },
        "notes": [
            "Replay speed reflects downloading sparse shards + applying patches into LMDB.",
            "Rollback speed reflects applying inverse patch sets from cached raw shard data."
        ],
    }
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
