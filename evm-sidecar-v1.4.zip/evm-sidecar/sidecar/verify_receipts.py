from __future__ import annotations
import argparse, os, json
from typing import Dict, Any, List
import requests

from .receipts import verify_receipt

def get_info(relay: str) -> Dict[str, Any]:
    r = requests.get(f"{relay}/v1/relay/info", timeout=30)
    r.raise_for_status()
    return r.json()

def get_receipt(relay: str, chain_id: str, block_no: int) -> Dict[str, Any]:
    r = requests.get(f"{relay}/v1/chain/{chain_id}/block/{block_no}/receipt", timeout=30)
    r.raise_for_status()
    return r.json()

def main():
    ap = argparse.ArgumentParser(prog="sidecar.verify_receipts")
    ap.add_argument("--relay", required=True, help="Relay base URL")
    ap.add_argument("--chain-id", default=os.environ.get("SIDECAR_CHAIN_ID","1"))
    ap.add_argument("--start", type=int, required=True)
    ap.add_argument("--count", type=int, default=200)
    args = ap.parse_args()

    relay = args.relay.rstrip("/")
    info = get_info(relay)
    algo = info.get("algo")
    pk = info.get("publicKeyB64")
    if algo != "ed25519" or not pk:
        raise SystemExit("Relay does not expose an ed25519 public key; cannot publicly verify receipts.")

    ok = 0
    bad = 0
    for b in range(args.start, args.start + args.count):
        rec = get_receipt(relay, args.chain_id, b)
        if verify_receipt(rec, pk):
            ok += 1
        else:
            bad += 1
            print(f"[BAD] block={b} receiptSig={rec.get('sig')}")
    out = {"relay": relay, "chainId": args.chain_id, "start": args.start, "count": args.count, "ok": ok, "bad": bad}
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
