from __future__ import annotations
import os, time
from typing import Dict, Any, List, Tuple, Optional
from .codec import (
    H, HASH_NAME, Patch, encode_patch_list, compress, empty_patch_list_raw,
    bytes_to_hex
)
from .merkle import merkle_root
from .bundle_store import write_bundle_atomic, prune_keep_last, read_manifest, list_blocks, delete_blocks_after
from .rpc_pool import RpcPool
from .tracer_geth import trace_block_state_deltas
from .receipts import ReceiptSigner

def shard_leaf(shard_id: int, raw: bytes) -> bytes:
    return H(b"shard|" + shard_id.to_bytes(2, "big") + H(raw))

def build_block_bundle(
    pool: RpcPool,
    signer: ReceiptSigner,
    chain_id: str,
    bundles_dir: str,
    block_no: int,
    include_storage: bool,
    compress_level: int,
    meta_extra: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    patches, blk_meta, trace_mode, trace_errs = trace_block_state_deltas(pool, block_no, include_storage=include_storage)
    patches.sort(key=lambda p: p.sort_key())

    shard_map: Dict[int, List[Patch]] = {}
    for p in patches:
        shard_map.setdefault(p.shard(), []).append(p)

    # Sparse blobs on disk, dense leaves for MAC
    empty_raw = empty_patch_list_raw()
    empty_leaf = [shard_leaf(i, empty_raw) for i in range(256)]

    shard_blobs: Dict[int, bytes] = {}
    shard_hashes_hex: Dict[int, str] = {}
    leaves: List[bytes] = empty_leaf[:]  # dense

    compressor_kind = "gzip"

    for sid, plist in shard_map.items():
        raw = encode_patch_list(plist)
        compressor_kind, blob = compress(raw, level=compress_level)
        shard_blobs[sid] = blob
        leaf = shard_leaf(sid, raw)
        leaves[sid] = leaf
        shard_hashes_hex[sid] = bytes_to_hex(leaf)

    mac = merkle_root(leaves)
    mac_hex = bytes_to_hex(mac)

    receipt = signer.sign(chain_id, block_no, blk_meta["hash"], mac_hex).to_dict()

    meta = {
        "brand": "EVM SideCar",
        "feature": "Fast Replay",
        "infra": "SideCar L2 infra",
        "traceMode": trace_mode,
        "traceErrors": trace_errs,
        "patchCount": len(patches),
        "rpcEndpoint": pool.endpoint(),
        "includeStorage": bool(include_storage),
        "shardsNonEmpty": len(shard_map),
    }
    if meta_extra:
        meta.update(meta_extra)

    write_bundle_atomic(
        bundles_dir=bundles_dir,
        chain_id=chain_id,
        block_no=block_no,
        block_hash=blk_meta["hash"],
        parent_hash=blk_meta["parentHash"],
        compressor=compressor_kind,
        hash_name=HASH_NAME,
        mac_root_hex=mac_hex,
        shard_blobs=shard_blobs,
        shard_hashes_hex=shard_hashes_hex,
        meta=meta,
        receipt=receipt
    )

    return {
        "blockNo": block_no,
        "blockHash": blk_meta["hash"],
        "parentHash": blk_meta["parentHash"],
        "mac": mac_hex,
        "traceMode": trace_mode,
        "traceErrors": trace_errs,
        "patchCount": len(patches),
        "nonEmptyShards": len(shard_map),
        "rpc": pool.endpoint(),
        "receipt": receipt,
    }

def _find_last_common_ancestor(pool: RpcPool, bundles_dir: str, chain_id: str, start_from: int, lookback: int) -> int:
    """
    Find highest block <= start_from that matches our stored manifest hash == chain hash.
    Returns block number of last common ancestor, or 0 if none found.
    """
    blocks = list_blocks(bundles_dir, chain_id)
    if not blocks:
        return 0
    lo = max(0, start_from - lookback)
    # Walk down from start_from to lo
    for b in range(start_from, lo - 1, -1):
        if b not in blocks:
            continue
        try:
            man = read_manifest(bundles_dir, chain_id, b)
            chain_blk = pool.call("eth_getBlockByNumber", [hex(b), False])
            if chain_blk and chain_blk.get("hash") == man.get("blockHash"):
                return b
        except Exception:
            pass
    return 0

def run_forever():
    rpcs = os.environ.get("SIDECAR_RPC_URL", "http://127.0.0.1:8545")
    urls = [u.strip() for u in rpcs.split(",") if u.strip()]
    chain_id = os.environ.get("SIDECAR_CHAIN_ID", "1")
    bundles_dir = os.environ.get("SIDECAR_BUNDLES_DIR", "./bundles")
    keep_blocks = int(os.environ.get("SIDECAR_KEEP_BLOCKS", "512"))
    start_block = int(os.environ.get("SIDECAR_START_BLOCK", "1"))
    poll_secs = float(os.environ.get("SIDECAR_POLL_SECS", "2"))
    include_storage = os.environ.get("SIDECAR_INCLUDE_STORAGE", "1") != "0"
    compress_level = int(os.environ.get("SIDECAR_COMPRESS_LEVEL", "8"))
    rpc_timeout = float(os.environ.get("SIDECAR_RPC_TIMEOUT", "60"))
    rpc_retries = int(os.environ.get("SIDECAR_RPC_RETRIES", "2"))
    reorg_lookback = int(os.environ.get("SIDECAR_REORG_LOOKBACK", str(max(keep_blocks, 2048))))

    pool = RpcPool(urls, timeout_s=rpc_timeout, retries=rpc_retries,
        rps=float(os.environ.get('SIDECAR_RPC_RPS','50')),
        burst=int(os.environ.get('SIDECAR_RPC_BURST','50')),
        fail_threshold=int(os.environ.get('SIDECAR_RPC_FAIL_THRESHOLD','5')),
        cooldown_s=float(os.environ.get('SIDECAR_RPC_COOLDOWN_SECS','10')),
    )
    signer = ReceiptSigner(bundles_dir)

    print(f"[SideCar Relay v1.2] chainId={chain_id} rpcs={len(urls)} bundles={bundles_dir} keep={keep_blocks} start={start_block} relayId={signer.relay_id} algo={signer.algo}")

    b = start_block
    last_block_hash: Optional[str] = None

    # If resuming from disk, set b to last+1
    existing = list_blocks(bundles_dir, chain_id)
    if existing:
        b = max(existing) + 1

    while True:
        try:
            # Check continuity against chain + our last manifest
            if existing:
                prev = b - 1
                try:
                    man_prev = read_manifest(bundles_dir, chain_id, prev)
                    chain_cur = pool.call("eth_getBlockByNumber", [hex(b), False])
                    if chain_cur and chain_cur.get("parentHash") != man_prev.get("blockHash"):
                        # Reorg detected
                        lca = _find_last_common_ancestor(pool, bundles_dir, chain_id, prev, reorg_lookback)
                        removed = delete_blocks_after(bundles_dir, chain_id, lca)
                        existing = list_blocks(bundles_dir, chain_id)
                        b = (lca + 1) if lca > 0 else start_block
                        print(f"[reorg] detected at b={prev}->{b}; lca={lca} removed={removed}")
                        time.sleep(0.25)
                        continue
                except Exception:
                    pass

            out = build_block_bundle(
                pool=pool,
                signer=signer,
                chain_id=chain_id,
                bundles_dir=bundles_dir,
                block_no=b,
                include_storage=include_storage,
                compress_level=compress_level,
            )
            removed = prune_keep_last(bundles_dir, chain_id, keep_blocks)
            existing = list_blocks(bundles_dir, chain_id)
            print(f"[ok] block={b} patches={out['patchCount']} nonEmptyShards={out['nonEmptyShards']} mac={out['mac'][:18]}... pruned={removed} rpc={out['rpc']} receiptAlgo={out['receipt']['algo']}")
            b += 1
        except Exception:
            time.sleep(poll_secs)
