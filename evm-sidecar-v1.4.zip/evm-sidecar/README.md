# EVM SideCar — Fast Replay + SideCar L2 Infra (v1.4)

You asked for:
- **EVM SideCar** (system name)
- **Fast Replay** (feature)
- **SideCar L2 Infra** (distribution layer)
- Chunking + pruning, per-block tracing (or per-tx fallback), delta batching + compression
- **MAC v1** = Merkle root over *sharded delta bundles* with **partial proofs**
- Fast reorg replay (rollback N blocks by reversing delta bundles)
- LMDB backend (fast local state), plus basic write-amp / disk stats
- Downloadable zip (this repo)

This repo ships two components:

## 1) SideCar Relay (producer + HTTP API)
- Connects to an EVM JSON-RPC endpoint
- Pulls blocks sequentially
- Computes **SideCar Bundles** (state deltas) using:
  - `debug_traceBlockByNumber` (preferred)
  - falls back to `debug_traceTransaction` per tx
- Chunks deltas into **256 shards** (by first byte of address)
- Stores only **non-empty shard blobs** (sparse storage)
- Computes **MAC v1** as a **dense Merkle root** over 256 leaves:
  - Non-empty shard: `leaf[i] = H("shard"|i|H(raw_patches_i))`
  - Empty shard: `leaf[i] = EMPTY_LEAF[i]` where `raw_patches_i` is the canonical empty patch-list encoding
- Serves artifacts:
  - manifest (includes shard hashes + MAC)
  - shard blobs (compressed)
  - shard proof (full Merkle path)

## 2) Fast Replay (consumer)
- Downloads manifest + only the non-empty shards
- Verifies:
  - per-shard hash
  - MAC v1 root (dense reconstruction w/ empty leaves)
  - optional proof for selected shards
- Applies patches to local **LMDB state**
- Supports **reorg rollback**:
  - keeps a local cache of applied blocks (patches)
  - rolls back by applying inverse patches in reverse order

---

# Quickstart

## Install
```bash
python -m venv .venv && source .venv/bin/activate
pip install -U pip
pip install -e ".[perf]"
```

## Run Relay (HTTP API + background producer)
Set env vars:
```bash
export SIDECAR_RPC_URL="http://127.0.0.1:8545"
export SIDECAR_CHAIN_ID="1"
export SIDECAR_BUNDLES_DIR="./bundles"
export SIDECAR_KEEP_BLOCKS="512"
export SIDECAR_START_BLOCK="1"
export SIDECAR_POLL_SECS="2"
export SIDECAR_PORT="8080"
python -m sidecar.api_server
```

## Run Fast Replay (consume from relay, apply locally)
```bash
export SIDECAR_RELAY_URL="http://127.0.0.1:8080"
export SIDECAR_STATE_DIR="./state_lmdb"
python -m sidecar.fast_replay --from-block 1 --count 50 --verify-mac
```

## Rollback last N applied blocks (reorg simulation)
```bash
python -m sidecar.fast_replay --rollback 10
```

---

# API

- `GET /health`
- `GET /v1/chain/{chainId}/block/{n}/manifest`
- `GET /v1/chain/{chainId}/block/{n}/mac`
- `GET /v1/chain/{chainId}/block/{n}/shard/{id}`
- `GET /v1/chain/{chainId}/block/{n}/proof/{id}`  (full Merkle sibling path)

---

# Notes / Reality

Producing deltas requires debug tracing. Many public RPCs don’t expose `debug_*`. If your RPC lacks tracing:
- run a local node with tracing enabled, or
- run Relay in “hosting mode” (future upgrade): accept externally produced bundles; consumers still verify MAC/proofs.

This MVP does **not** compute Ethereum’s canonical MPT `stateRoot`. SideCar is an *acceleration artifact* that can be validated against execution and used for fast replay/indexing.

---

# Repo Layout

```
sidecar/
  codec.py          # patch encoding + (zstd/gzip) compression + hashing
  merkle.py         # MAC v1 (dense merkle) + proofs
  rpc_pool.py       # multi-endpoint JSON-RPC failover
  tracer_geth.py    # prestate tracer delta extraction
  bundle_store.py   # bundle IO (sparse shards) + manifest
  state_lmdb.py     # LMDB state store apply/commitment
  relay_worker.py   # block loop producer
  api_server.py     # FastAPI server + proof endpoint
  fast_replay.py    # consumer + rollback cache
scripts/
  run_relay.sh
  run_replay.sh
```


## v1.4 Additions
- **Atomic bundle writes** (crash-safe)
- **Reorg-aware Relay** (rewinds to last common ancestor and rebuilds)
- **SideCar Receipts** per block (Ed25519 preferred, HMAC fallback)
- **Benchmark harness**: `python -m sidecar.bench replay ...` and multi-relay compare: `python -m sidecar.relay_compare ...`
