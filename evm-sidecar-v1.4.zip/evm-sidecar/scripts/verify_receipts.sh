#!/usr/bin/env bash
set -euo pipefail
python -m sidecar.verify_receipts --relay "${1:?relay_url}" --start "${2:-1}" --count "${3:-200}"
