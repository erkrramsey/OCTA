#!/usr/bin/env bash
set -euo pipefail
python -m sidecar.quorum --relays "${1:?relays_comma}" --start "${2:-1}" --count "${3:-200}" --m "${4:-2}"
