#!/usr/bin/env bash
set -euo pipefail
export SIDECAR_RELAY_URL="${SIDECAR_RELAY_URL:-http://127.0.0.1:8080}"
export SIDECAR_CHAIN_ID="${SIDECAR_CHAIN_ID:-1}"
export SIDECAR_STATE_DIR="${SIDECAR_STATE_DIR:-./score_state_lmdb}"
python -m sidecar.scorecard --start "${1:-1}" --count "${2:-500}" --rollback "${3:-50}" --verify-mac
